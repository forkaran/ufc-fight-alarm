# 🥊 UFC Fight Alarm — Android App

Automatically rings a loud alarm ~3 minutes before each UFC fight starts, by detecting when Wikipedia is updated with the previous fight's result.

---

## How It Works

1. **Auto-detects** the next upcoming UFC event by scraping Wikipedia's UFC events list
2. **Displays the full fight card** from the event's Wikipedia page
3. **Polls Wikipedia every 60 seconds** during the event for result updates
4. When a fight result is detected → **starts a 3-minute countdown**
5. At 0:00 → **LOUD ALARM sounds** + full-screen alert shows (even on lock screen)
6. Dismiss the alarm when you're ready

---

## Build Instructions

### Requirements
- Android Studio Hedgehog (2023.1.1) or newer
- JDK 17
- Android SDK 34
- Android device or emulator running Android 8.0+ (API 26+)

### Steps

1. **Open in Android Studio**
   ```
   File → Open → select the UFCAlarm folder
   ```

2. **Sync Gradle**
   - Android Studio will prompt to sync. Click "Sync Now"
   - Wait for dependencies to download (jsoup, coroutines, etc.)

3. **Build & Run**
   ```
   Run → Run 'app'
   ```
   Or build APK:
   ```
   Build → Build Bundle(s) / APK(s) → Build APK(s)
   ```
   APK will be at: `app/build/outputs/apk/debug/app-debug.apk`

### From Command Line
```bash
cd UFCAlarm
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

---

## App Usage

1. Open the app
2. Tap **"▶ Start Monitoring"**
3. The app will auto-find the next UFC event and display the fight card
4. Keep your phone on (or let it run in background) during the event
5. The alarm will ring ~3 minutes after each fight result appears on Wikipedia

### Permissions Required
- **Internet** — to poll Wikipedia
- **Notifications** — for fight status updates
- **Foreground Service** — to keep polling while app is in background
- **Wake Lock** — to ensure alarm fires even when screen is off

---

## Architecture

```
UFCAlarm/
├── Models.kt              — Fight, FightResult, UFCEvent data classes
├── WikipediaScraper.kt    — Jsoup-based Wikipedia scraper + poller
├── WikiPollingService.kt  — Foreground service: polls every 60s, manages countdown
├── AlarmService.kt        — Plays loud alarm sound at max volume
├── AlarmActivity.kt       — Full-screen alarm screen (shows on lock screen)
├── AlarmReceiver.kt       — BroadcastReceiver for alarm triggers
├── FightCardAdapter.kt    — RecyclerView adapter for fight list
└── MainActivity.kt        — Main UI, shows fight card + monitoring controls
```

---

## Notes

- Wikipedia results typically appear **2–10 minutes** after a fight ends (depends on how fast editors update)
- The app will work even when the screen is off (foreground service)
- If the event page URL changes, the app auto-searches the UFC events list page
- For events outside the next 14-day window, you can manually set the Wikipedia URL in the service

---

## Troubleshooting

**No event found:**
- Check that there's a UFC event in the next 14 days
- Ensure internet connection is active

**Alarm not loud enough:**
- Go to Android Settings → Sound → Alarm volume → set to max

**App killed in background:**
- Go to Android Settings → Battery → find "UFC Fight Alarm" → set to "Unrestricted"

---

## Dependencies

- `org.jsoup:jsoup:1.17.1` — HTML parsing for Wikipedia
- `org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3` — async polling
- `androidx.work:work-runtime-ktx:2.9.0` — background work
- `com.google.android.material:material:1.10.0` — UI components
