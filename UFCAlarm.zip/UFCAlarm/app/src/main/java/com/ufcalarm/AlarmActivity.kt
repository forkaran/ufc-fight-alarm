package com.ufcalarm

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.TextView

class AlarmActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Show over lock screen
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            keyguardManager.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }

        setContentView(R.layout.activity_alarm)

        val fighter1 = intent.getStringExtra("fighter1") ?: "Fighter 1"
        val fighter2 = intent.getStringExtra("fighter2") ?: "Fighter 2"
        val weightClass = intent.getStringExtra("weight_class") ?: ""

        findViewById<TextView>(R.id.tv_fight_title).text = "$fighter1\nvs\n$fighter2"
        if (weightClass.isNotEmpty()) {
            findViewById<TextView>(R.id.tv_weight_class).text = weightClass
        }

        findViewById<Button>(R.id.btn_dismiss).setOnClickListener {
            AlarmService.stopAlarm(this)
            finish()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val fighter1 = intent.getStringExtra("fighter1") ?: "Fighter 1"
        val fighter2 = intent.getStringExtra("fighter2") ?: "Fighter 2"
        val weightClass = intent.getStringExtra("weight_class") ?: ""
        findViewById<TextView>(R.id.tv_fight_title).text = "$fighter1\nvs\n$fighter2"
        if (weightClass.isNotEmpty()) {
            findViewById<TextView>(R.id.tv_weight_class).text = weightClass
        }
    }
}
