package com.ufcalarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Log.d("AlarmReceiver", "Received: ${intent.action}")
        val f1 = intent.getStringExtra("fighter1") ?: ""
        val f2 = intent.getStringExtra("fighter2") ?: ""
        AlarmService.startAlarm(context, f1, f2)
    }
}
