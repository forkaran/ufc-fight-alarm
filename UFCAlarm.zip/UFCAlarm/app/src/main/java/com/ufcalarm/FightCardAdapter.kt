package com.ufcalarm

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Switch
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FightCardAdapter(
    private var fights: List<Fight>,
    private val context: Context
) : RecyclerView.Adapter<FightCardAdapter.FightViewHolder>() {

    class FightViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvWeightClass: TextView = view.findViewById(R.id.tv_weight_class)
        val tvFighters: TextView = view.findViewById(R.id.tv_fighters)
        val tvResult: TextView = view.findViewById(R.id.tv_result)
        val tvStatus: TextView = view.findViewById(R.id.tv_status)
        val switchAlarm: Switch = view.findViewById(R.id.switch_alarm)
        val tvAlarmLabel: TextView = view.findViewById(R.id.tv_alarm_label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FightViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_fight, parent, false)
        return FightViewHolder(view)
    }

    override fun onBindViewHolder(holder: FightViewHolder, position: Int) {
        val fight = fights[position]

        holder.tvWeightClass.text = fight.weightClass.ifEmpty { "UFC Fight" }
        holder.tvFighters.text = "${fight.fighter1}  vs  ${fight.fighter2}"

        // Fight result / status
        when {
            fight.result != null -> {
                val r = fight.result!!
                holder.tvResult.visibility = View.VISIBLE
                holder.tvResult.text = "✅ ${r.winner} via ${r.method} (R${r.round} ${r.time})"
                holder.tvStatus.text = "DONE"
                holder.tvStatus.setTextColor(Color.parseColor("#4CAF50"))
                holder.itemView.alpha = 0.6f
                // Disable toggle for completed fights
                holder.switchAlarm.isEnabled = false
                holder.tvAlarmLabel.setTextColor(Color.parseColor("#666666"))
            }
            else -> {
                holder.tvResult.visibility = View.GONE
                holder.tvStatus.text = "UPCOMING"
                holder.tvStatus.setTextColor(Color.parseColor("#FF9800"))
                holder.itemView.alpha = 1.0f
                holder.switchAlarm.isEnabled = true
                holder.tvAlarmLabel.setTextColor(if (fight.alarmEnabled) Color.parseColor("#E94560") else Color.parseColor("#888888"))
            }
        }

        // Title fight highlight
        if (fight.isTitleFight) {
            holder.tvWeightClass.setTextColor(Color.parseColor("#FFD700"))
            holder.tvWeightClass.text = "🏆 ${fight.weightClass}"
        } else {
            holder.tvWeightClass.setTextColor(Color.parseColor("#AAAAAA"))
        }

        // Alarm toggle — suppress listener before setting checked state to avoid feedback loop
        holder.switchAlarm.setOnCheckedChangeListener(null)
        holder.switchAlarm.isChecked = fight.alarmEnabled
        holder.switchAlarm.setOnCheckedChangeListener { _, isChecked ->
            fight.alarmEnabled = isChecked
            holder.tvAlarmLabel.setTextColor(
                if (isChecked) Color.parseColor("#E94560") else Color.parseColor("#888888")
            )
            holder.tvAlarmLabel.text = if (isChecked) "🔔 Alarm ON" else "Alarm OFF"

            // Notify service of the toggle
            val intent = Intent(context, WikiPollingService::class.java).apply {
                action = WikiPollingService.ACTION_TOGGLE_ALARM
                putExtra(WikiPollingService.EXTRA_FIGHT_ID, fight.id)
                putExtra(WikiPollingService.EXTRA_ALARM_ENABLED, isChecked)
            }
            context.startService(intent)
        }

        holder.tvAlarmLabel.text = if (fight.alarmEnabled) "🔔 Alarm ON" else "Alarm OFF"
    }

    override fun getItemCount() = fights.size

    fun updateFights(newFights: List<Fight>) {
        fights = newFights
        notifyDataSetChanged()
    }
}
