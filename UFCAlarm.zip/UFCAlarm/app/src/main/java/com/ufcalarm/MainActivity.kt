package com.ufcalarm

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var tvEventName: TextView
    private lateinit var tvEventDate: TextView
    private lateinit var tvEventVenue: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvCountdown: TextView
    private lateinit var btnStartMonitoring: Button
    private lateinit var btnStopMonitoring: Button
    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var layoutEventInfo: View
    private lateinit var tvPollStatus: TextView

    private var adapter: FightCardAdapter? = null
    private var isMonitoring = false

    private val broadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                WikiPollingService.BROADCAST_FIGHT_UPDATE -> {
                    refreshUI()
                }
                WikiPollingService.BROADCAST_COUNTDOWN_UPDATE -> {
                    val secondsLeft = intent.getLongExtra(WikiPollingService.EXTRA_SECONDS_LEFT, 0)
                    val nextFightName = intent.getStringExtra(WikiPollingService.EXTRA_NEXT_FIGHT_NAME) ?: ""
                    val m = secondsLeft / 60
                    val s = secondsLeft % 60
                    tvCountdown.visibility = View.VISIBLE
                    tvCountdown.text = "⏱ Next fight in %d:%02d\n%s".format(m, s, nextFightName)
                }
                WikiPollingService.BROADCAST_ALARM_RING -> {
                    val fightName = intent.getStringExtra(WikiPollingService.EXTRA_NEXT_FIGHT_NAME) ?: ""
                    tvCountdown.text = "🔔 FIGHT STARTING: $fightName"
                    tvCountdown.visibility = View.VISIBLE
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindViews()
        setupRecyclerView()
        requestPermissions()

        btnStartMonitoring.setOnClickListener {
            startMonitoring()
        }

        btnStopMonitoring.setOnClickListener {
            stopMonitoring()
        }
    }

    private fun bindViews() {
        tvEventName = findViewById(R.id.tv_event_name)
        tvEventDate = findViewById(R.id.tv_event_date)
        tvEventVenue = findViewById(R.id.tv_event_venue)
        tvStatus = findViewById(R.id.tv_status)
        tvCountdown = findViewById(R.id.tv_countdown)
        btnStartMonitoring = findViewById(R.id.btn_start_monitoring)
        btnStopMonitoring = findViewById(R.id.btn_stop_monitoring)
        recyclerView = findViewById(R.id.recycler_fights)
        progressBar = findViewById(R.id.progress_bar)
        layoutEventInfo = findViewById(R.id.layout_event_info)
        tvPollStatus = findViewById(R.id.tv_poll_status)
    }

    private fun setupRecyclerView() {
        adapter = FightCardAdapter(emptyList(), this)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }

    private fun startMonitoring() {
        isMonitoring = true
        btnStartMonitoring.isEnabled = false
        btnStopMonitoring.isEnabled = true
        progressBar.visibility = View.VISIBLE
        tvStatus.text = "🔍 Loading next UFC event from Wikipedia..."

        val serviceIntent = Intent(this, WikiPollingService::class.java).apply {
            action = WikiPollingService.ACTION_START
        }
        startForegroundService(serviceIntent)
    }

    private fun stopMonitoring() {
        isMonitoring = false
        btnStartMonitoring.isEnabled = true
        btnStopMonitoring.isEnabled = false
        tvStatus.text = "Monitoring stopped"
        tvCountdown.visibility = View.GONE
        progressBar.visibility = View.GONE
        tvPollStatus.text = ""

        val serviceIntent = Intent(this, WikiPollingService::class.java).apply {
            action = WikiPollingService.ACTION_STOP
        }
        startService(serviceIntent)
    }

    private fun refreshUI() {
        val event = WikiPollingService.EventStore.currentEvent
        progressBar.visibility = View.GONE

        if (event == null) {
            tvStatus.text = "❌ No upcoming UFC event found"
            layoutEventInfo.visibility = View.GONE
            tvPollStatus.text = ""
            return
        }

        layoutEventInfo.visibility = View.VISIBLE
        tvEventName.text = event.name
        tvEventDate.text = "📅 ${event.date}"
        tvEventVenue.text = "📍 ${event.venue}"

        val completedCount = event.fights.count { it.result != null }
        val totalCount = event.fights.size
        tvStatus.text = if (isMonitoring) {
            "✅ Monitoring active | $completedCount/$totalCount fights completed"
        } else {
            "$completedCount/$totalCount fights completed"
        }

        tvPollStatus.text = "Last checked: ${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())}"

        adapter?.updateFights(event.fights.toList())
    }

    private fun requestPermissions() {
        val permissions = mutableListOf<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        if (permissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissions.toTypedArray(), 100)
        }
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter().apply {
            addAction(WikiPollingService.BROADCAST_FIGHT_UPDATE)
            addAction(WikiPollingService.BROADCAST_COUNTDOWN_UPDATE)
            addAction(WikiPollingService.BROADCAST_ALARM_RING)
        }
        registerReceiver(broadcastReceiver, filter, RECEIVER_NOT_EXPORTED)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(broadcastReceiver)
    }
}
