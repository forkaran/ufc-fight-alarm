package com.ufcalarm

data class Fight(
    val id: Int,
    val fighter1: String,
    val fighter2: String,
    val weightClass: String,
    val isTitleFight: Boolean = false,
    var result: FightResult? = null,
    var isCurrentFight: Boolean = false,
    var alarmTriggered: Boolean = false,
    var alarmEnabled: Boolean = false  // User manually toggles ON to get alarm for this fight
)

data class FightResult(
    val winner: String,
    val method: String,
    val round: Int,
    val time: String
)

data class UFCEvent(
    val name: String,
    val date: String,
    val venue: String,
    val wikipediaUrl: String,
    val fights: MutableList<Fight> = mutableListOf()
)

sealed class AppState {
    object Loading : AppState()
    data class EventLoaded(val event: UFCEvent) : AppState()
    data class Error(val message: String) : AppState()
    object NoUpcomingEvent : AppState()
}

sealed class AlarmState {
    object Idle : AlarmState()
    data class Countdown(val fightId: Int, val secondsRemaining: Long, val nextFight: Fight) : AlarmState()
    data class Ringing(val fight: Fight) : AlarmState()
}
