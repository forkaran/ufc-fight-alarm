package com.ufcalarm

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

class WikiPollingService : Service() {

    companion object {
        const val TAG = "WikiPollingService"
        const val CHANNEL_ID = "ufc_polling_channel"
        const val NOTIFICATION_ID = 1001
        const val POLL_INTERVAL_MS = 60_000L
        const val ALARM_DELAY_MS = 3 * 60 * 1000L

        const val ACTION_START = "com.ufcalarm.START_POLLING"
        const val ACTION_STOP = "com.ufcalarm.STOP_POLLING"
        const val ACTION_TOGGLE_ALARM = "com.ufcalarm.TOGGLE_ALARM"
        const val EXTRA_FIGHT_ID = "fight_id"
        const val EXTRA_ALARM_ENABLED = "alarm_enabled"

        const val BROADCAST_FIGHT_UPDATE = "com.ufcalarm.FIGHT_UPDATE"
        const val BROADCAST_COUNTDOWN_UPDATE = "com.ufcalarm.COUNTDOWN_UPDATE"
        const val BROADCAST_ALARM_RING = "com.ufcalarm.ALARM_RING"
        const val EXTRA_SECONDS_LEFT = "seconds_left"
        const val EXTRA_NEXT_FIGHT_NAME = "next_fight_name"
        const val EXTRA_NEXT_FIGHT_ID = "next_fight_id"
    }

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var currentEvent: UFCEvent? = null
    private var pollingJob: Job? = null
    private var countdownJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startForeground(NOTIFICATION_ID, buildNotification("Loading UFC event..."))
                startPolling()
            }
            ACTION_STOP -> {
                stopPolling()
                stopSelf()
            }
            ACTION_TOGGLE_ALARM -> {
                val fightId = intent.getIntExtra(EXTRA_FIGHT_ID, -1)
                val enabled = intent.getBooleanExtra(EXTRA_ALARM_ENABLED, false)
                if (fightId >= 0) {
                    currentEvent?.fights?.find { it.id == fightId }?.alarmEnabled = enabled
                    EventStore.currentEvent = currentEvent
                    Log.d(TAG, "Fight $fightId alarm ${if (enabled) "ENABLED" else "DISABLED"}")
                }
            }
        }
        return START_STICKY
    }

    private fun startPolling() {
        pollingJob?.cancel()
        pollingJob = serviceScope.launch {
            updateNotification("Loading UFC event data...")
            try {
                currentEvent = WikipediaScraper.findNextUFCEvent()
                EventStore.currentEvent = currentEvent
                if (currentEvent != null) {
                    broadcastFightUpdate()
                    updateNotification("Monitoring: ${currentEvent!!.name}")
                } else {
                    updateNotification("No upcoming UFC event found")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error during initial load", e)
                updateNotification("Error loading event. Retrying...")
            }

            while (isActive) {
                delay(POLL_INTERVAL_MS)
                pollForUpdates()
            }
        }
    }

    private suspend fun pollForUpdates() {
        val event = currentEvent ?: return
        try {
            Log.d(TAG, "Polling Wikipedia...")
            val newlyCompletedIds = WikipediaScraper.checkForNewResults(event)
            EventStore.currentEvent = currentEvent

            if (newlyCompletedIds.isNotEmpty()) {
                broadcastFightUpdate()

                for (completedFightId in newlyCompletedIds) {
                    // Find the next fight that has alarm enabled AND hasn't been triggered yet
                    val nextFight = event.fights.firstOrNull {
                        it.id > completedFightId && it.result == null && it.alarmEnabled && !it.alarmTriggered
                    } ?: continue

                    Log.d(TAG, "Starting 3-min countdown for: ${nextFight.fighter1} vs ${nextFight.fighter2}")
                    startCountdown(nextFight)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error during poll", e)
        }
    }

    private fun startCountdown(nextFight: Fight) {
        countdownJob?.cancel()
        nextFight.alarmTriggered = true  // Prevent double-triggering
        countdownJob = serviceScope.launch {
            val startTime = System.currentTimeMillis()

            while (isActive) {
                val elapsed = System.currentTimeMillis() - startTime
                val remaining = ALARM_DELAY_MS - elapsed

                if (remaining <= 0) {
                    ringAlarm(nextFight)
                    break
                }

                broadcastCountdown(remaining / 1000, nextFight)
                updateNotification("⏱ Next fight in ${formatTime(remaining / 1000)}: ${nextFight.fighter1} vs ${nextFight.fighter2}")
                delay(1000)
            }
        }
    }

    private fun ringAlarm(fight: Fight) {
        val alarmIntent = Intent(this, AlarmActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("fighter1", fight.fighter1)
            putExtra("fighter2", fight.fighter2)
            putExtra("weight_class", fight.weightClass)
        }
        startActivity(alarmIntent)
        AlarmService.startAlarm(this, fight.fighter1, fight.fighter2)

        val intent = Intent(BROADCAST_ALARM_RING).apply {
            `package` = packageName
            putExtra(EXTRA_NEXT_FIGHT_ID, fight.id)
            putExtra(EXTRA_NEXT_FIGHT_NAME, "${fight.fighter1} vs ${fight.fighter2}")
        }
        sendBroadcast(intent)
        updateNotification("🔔 FIGHT STARTING: ${fight.fighter1} vs ${fight.fighter2}")
    }

    private fun broadcastFightUpdate() {
        sendBroadcast(Intent(BROADCAST_FIGHT_UPDATE).apply { `package` = packageName })
    }

    private fun broadcastCountdown(secondsLeft: Long, nextFight: Fight) {
        sendBroadcast(Intent(BROADCAST_COUNTDOWN_UPDATE).apply {
            `package` = packageName
            putExtra(EXTRA_SECONDS_LEFT, secondsLeft)
            putExtra(EXTRA_NEXT_FIGHT_NAME, "${nextFight.fighter1} vs ${nextFight.fighter2}")
            putExtra(EXTRA_NEXT_FIGHT_ID, nextFight.id)
        })
    }

    private fun stopPolling() {
        pollingJob?.cancel()
        countdownJob?.cancel()
        serviceScope.cancel()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(CHANNEL_ID, "UFC Fight Monitoring", NotificationManager.IMPORTANCE_LOW)
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stopPi = PendingIntent.getService(this, 1,
            Intent(this, WikiPollingService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("UFC Fight Alarm")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pi)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopPi)
            .setOngoing(true).build()
    }

    private fun updateNotification(text: String) {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun formatTime(seconds: Long) = "%d:%02d".format(seconds / 60, seconds % 60)

    override fun onDestroy() {
        super.onDestroy()
        stopPolling()
    }

    object EventStore {
        var currentEvent: UFCEvent? = null
    }
}
