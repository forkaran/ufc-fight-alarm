package com.ufcalarm

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.text.SimpleDateFormat
import java.util.*

object WikipediaScraper {

    private const val TAG = "WikipediaScraper"
    private const val BASE_URL = "https://en.wikipedia.org"
    private const val USER_AGENT = "UFCAlarmApp/1.0 (Android; contact: ufcalarm@example.com)"

    /**
     * Find the next upcoming UFC event by scraping the UFC Wikipedia events list.
     * Returns the Wikipedia URL for the next event.
     */
    suspend fun findNextUFCEvent(): UFCEvent? = withContext(Dispatchers.IO) {
        try {
            val doc = fetchPage("$BASE_URL/wiki/List_of_UFC_events") ?: return@withContext null

            val today = Calendar.getInstance()
            val dateFormat = SimpleDateFormat("MMMM d, yyyy", Locale.ENGLISH)

            // Find the upcoming events table - it's typically the first table with class wikitable
            val tables = doc.select("table.wikitable")

            for (table in tables) {
                val rows = table.select("tr")
                for (row in rows) {
                    val cells = row.select("td")
                    if (cells.size < 3) continue

                    // Try to parse event date from first cell
                    val dateText = cells[0].text().trim()
                    val eventDate = try {
                        dateFormat.parse(dateText)
                    } catch (e: Exception) {
                        // Try alternate format
                        try {
                            SimpleDateFormat("MMM d, yyyy", Locale.ENGLISH).parse(dateText)
                        } catch (e2: Exception) {
                            null
                        }
                    } ?: continue

                    val eventCal = Calendar.getInstance().apply { time = eventDate }

                    // Find events that are today or in the future (within next 14 days)
                    val diffDays = ((eventCal.timeInMillis - today.timeInMillis) / (1000 * 60 * 60 * 24)).toInt()

                    if (diffDays in -1..14) {
                        // This is the next/current event
                        val nameCell = cells[1]
                        val link = nameCell.select("a").firstOrNull()
                        val eventName = nameCell.text().trim()
                        val eventPath = link?.attr("href") ?: continue
                        val venue = if (cells.size > 2) cells[2].text().trim() else ""

                        Log.d(TAG, "Found next event: $eventName on $dateText")

                        val event = UFCEvent(
                            name = eventName,
                            date = dateText,
                            venue = venue,
                            wikipediaUrl = "$BASE_URL$eventPath"
                        )

                        // Now scrape the fight card from the event page
                        scrapeEventPage(event)
                        return@withContext event
                    }
                }
            }

            Log.w(TAG, "No upcoming UFC event found in the next 14 days")
            null
        } catch (e: Exception) {
            Log.e(TAG, "Error finding next UFC event", e)
            null
        }
    }

    /**
     * Scrape the fight card from a specific UFC event Wikipedia page.
     * Also checks for updated fight results.
     */
    suspend fun scrapeEventPage(event: UFCEvent): UFCEvent = withContext(Dispatchers.IO) {
        try {
            val doc = fetchPage(event.wikipediaUrl) ?: return@withContext event

            val fights = mutableListOf<Fight>()
            var fightId = 0

            // Look for fight card tables - Wikipedia UFC pages typically have tables
            // with headers containing "Weight class", "Fighter", "vs.", "Fighter", "Method"
            val tables = doc.select("table.wikitable, table.toccolours")

            for (table in tables) {
                val headerRow = table.select("tr").firstOrNull() ?: continue
                val headers = headerRow.select("th").map { it.text().lowercase() }

                val hasFightCard = headers.any { it.contains("weight") || it.contains("fighter") }
                if (!hasFightCard) continue

                val rows = table.select("tr").drop(1) // Skip header

                for (row in rows) {
                    val cells = row.select("td")
                    if (cells.size < 3) continue

                    val fight = parseFightRow(cells, fightId, headers) ?: continue
                    fights.add(fight)
                    fightId++
                }
            }

            // If table parsing failed, try alternate approach: look for fight sections
            if (fights.isEmpty()) {
                fights.addAll(parseFightsFromSections(doc, fightId))
            }

            // Update existing fights with new results without losing alarm state
            if (event.fights.isEmpty()) {
                event.fights.addAll(fights)
            } else {
                // Merge: update results for existing fights
                for (newFight in fights) {
                    val existing = event.fights.find {
                        it.fighter1.equals(newFight.fighter1, ignoreCase = true) ||
                        it.fighter2.equals(newFight.fighter2, ignoreCase = true)
                    }
                    if (existing != null && existing.result == null && newFight.result != null) {
                        existing.result = newFight.result
                        Log.d(TAG, "Updated result for fight: ${existing.fighter1} vs ${existing.fighter2} -> ${newFight.result}")
                    }
                }
            }

            Log.d(TAG, "Scraped ${event.fights.size} fights from ${event.name}")
        } catch (e: Exception) {
            Log.e(TAG, "Error scraping event page", e)
        }
        event
    }

    private fun parseFightRow(cells: List<org.jsoup.nodes.Element>, id: Int, headers: List<String>): Fight? {
        return try {
            // Common UFC Wikipedia table structure:
            // Weight class | Fighter 1 | vs. | Fighter 2 | Method | Round | Time | Notes

            val text = cells.map { it.text().trim() }
            if (text.size < 2) return null

            var weightClass = ""
            var fighter1 = ""
            var fighter2 = ""
            var method = ""
            var round = 0
            var time = ""
            var winner = ""

            // Try to detect column positions from headers
            when {
                headers.size >= 4 -> {
                    // Find weight class col
                    val wIdx = headers.indexOfFirst { it.contains("weight") }
                    val f1Idx = headers.indexOfFirst { it.contains("fighter") || it.contains("red") }
                    val f2Idx = headers.indexOfLast { it.contains("fighter") || it.contains("blue") }
                    val mIdx = headers.indexOfFirst { it.contains("method") }
                    val rIdx = headers.indexOfFirst { it.contains("round") }
                    val tIdx = headers.indexOfFirst { it.contains("time") }

                    weightClass = if (wIdx >= 0 && wIdx < text.size) text[wIdx] else ""
                    fighter1 = if (f1Idx >= 0 && f1Idx < text.size) text[f1Idx] else text.getOrElse(1) { "" }
                    fighter2 = if (f2Idx >= 0 && f2Idx < text.size) text[f2Idx] else text.getOrElse(3) { "" }
                    method = if (mIdx >= 0 && mIdx < text.size) text[mIdx] else ""
                    round = if (rIdx >= 0 && rIdx < text.size) text[rIdx].toIntOrNull() ?: 0 else 0
                    time = if (tIdx >= 0 && tIdx < text.size) text[tIdx] else ""
                }
                else -> {
                    // Fallback: assume standard order
                    weightClass = text.getOrElse(0) { "" }
                    fighter1 = text.getOrElse(1) { "" }
                    fighter2 = text.getOrElse(3) { "" }
                    method = text.getOrElse(4) { "" }
                    round = text.getOrElse(5) { "0" }.toIntOrNull() ?: 0
                    time = text.getOrElse(6) { "" }
                }
            }

            // Check for winner - often indicated by bold text or a "W" marker
            val boldText = cells.flatMap { it.select("b") }.map { it.text() }
            winner = boldText.firstOrNull { it.isNotEmpty() } ?: ""

            // Skip rows that don't look like fights
            if (fighter1.isEmpty() || fighter2.isEmpty()) return null
            if (fighter1.equals(fighter2, ignoreCase = true)) return null

            val isTitleFight = weightClass.contains("championship", ignoreCase = true) ||
                    weightClass.contains("title", ignoreCase = true)

            val result = if (method.isNotEmpty() && round > 0) {
                FightResult(
                    winner = winner.ifEmpty { fighter1 },
                    method = method,
                    round = round,
                    time = time
                )
            } else null

            Fight(
                id = id,
                fighter1 = fighter1,
                fighter2 = fighter2,
                weightClass = weightClass,
                isTitleFight = isTitleFight,
                result = result
            )
        } catch (e: Exception) {
            Log.w(TAG, "Failed to parse fight row", e)
            null
        }
    }

    private fun parseFightsFromSections(doc: Document, startId: Int): List<Fight> {
        val fights = mutableListOf<Fight>()
        var fightId = startId

        // Look for "vs." patterns in the page text
        val vsPattern = Regex("""([A-Z][a-z]+ [A-Z][a-z']+(?:\s[A-Z][a-z]+)?)\s+(?:vs\.?|v\.)\s+([A-Z][a-z]+ [A-Z][a-z']+(?:\s[A-Z][a-z]+)?)""")

        val pageText = doc.body()?.text() ?: return fights
        val matches = vsPattern.findAll(pageText)

        val seen = mutableSetOf<String>()
        for (match in matches) {
            val f1 = match.groupValues[1].trim()
            val f2 = match.groupValues[2].trim()
            val key = "${f1}|${f2}"

            if (key !in seen && f1 != f2 && f1.length > 4 && f2.length > 4) {
                seen.add(key)
                fights.add(Fight(id = fightId++, fighter1 = f1, fighter2 = f2, weightClass = ""))
            }
        }

        return fights
    }

    private fun fetchPage(url: String): Document? {
        return try {
            Jsoup.connect(url)
                .userAgent(USER_AGENT)
                .timeout(15000)
                .followRedirects(true)
                .get()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to fetch: $url", e)
            null
        }
    }

    /**
     * Check for any new fight results since last poll.
     * Returns list of fight IDs that newly have results.
     */
    suspend fun checkForNewResults(event: UFCEvent): List<Int> = withContext(Dispatchers.IO) {
        val prevResultIds = event.fights.filter { it.result != null }.map { it.id }.toSet()
        scrapeEventPage(event)
        val newResultIds = event.fights.filter { it.result != null }.map { it.id }.toSet()
        val newlyCompleted = newResultIds - prevResultIds
        newlyCompleted.toList()
    }
}
